<html>
<head>
<title>LOGIN</title>
</head>
<body>
<form method="POST" action="VALIDATE.php">
<h1><center>LOGIN FORM</center></h1>
<table border ="1" style="margin-left:auto;margin-right:auto;">
<tr><td>Username:</td><td><input type="text" name="user"
/></td></tr>
<tr><td>Enter Your EmailId:</td><td><input type="text" name="user"
/></td></tr>
<tr><td>Password:</td><td><input type="password" name="pass"
/></td></tr>
<input type="submit" value="Create File"><br><br>
<tr><td><input type="submit" value="Login" /></td><td>
<input type="reset" value="reset" /></td></tr>
</table>
</form>
</body>
</html>