<?php
session_start();
header("location:marks.php")


?>
<!doctype html>
<html>
    <head></head>
    <body>
  
            
    </body>
</html>